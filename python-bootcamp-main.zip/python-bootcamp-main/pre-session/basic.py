number = 6677  # integer 
 
number_decimal = 18.6 #cpp or java double or float

height = 1.8

name = ' Rohitash Chandra'  # string

print(number)
print(number, ' is number')
print(number_decimal, ' is decimal ')
print(height,'               is height ')
print(name)
print(name, ' is my name')

print(' lets calculate')


radius = 12.25
pi = 3.14

area_circle = pi * radius * radius 

print(area_circle, ' is area of the circle')


# triangle (ask the user for input)


print('Good day mate. This program claculates area of triangle')

print('please enter the base: ')
base = input()

print('please enter the height: ')
height = input()

print(base, height,  ' are the base and height, respectively')

area_triangle = 0.5 * int(base) * int(height)


print(area_triangle,  ' is the area of the triangle')