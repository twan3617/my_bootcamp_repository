### Recursion 

#### Factorials


 ![Factorial](recursion.png)

Figure Source: https://www.edureka.co/blog/recursion-in-python/