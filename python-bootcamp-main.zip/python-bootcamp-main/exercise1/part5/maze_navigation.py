'''FIND-PATH(x, y) 
    1. 	if (x,y outside maze) return false 
    2. 	if (x,y is goal) return true 
    3. 	if (x,y not open) return false 
    4. 	mark x,y as part of solution path 
    5. 	if (FIND-PATH(North of x,y) == true) return true 
    6. 	if (FIND-PATH(East of x,y) == true) return true 
    7. 	if (FIND-PATH(South of x,y) == true) return true 
    8. 	if (FIND-PATH(West of x,y) == true) return true 
    9. 	unmark x,y as part of solution path 
    10. return false '''


def find_path(x, y):
    if ( ):
        return False 
    if ( ):
        return False 







#-------------------



    
